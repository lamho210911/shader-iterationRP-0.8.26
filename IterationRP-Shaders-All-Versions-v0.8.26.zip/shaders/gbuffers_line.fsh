#version 430 compatibility


#include "/Lib/Settings.glsl"


#ifdef LINE_IMAGE_OUTPUT
    #include "/Lib/Programs/Gbuffers/Line_FS_IMAGE.glsl"
#else
    #include "/Lib/Programs/Gbuffers/Line_FS.glsl"
#endif