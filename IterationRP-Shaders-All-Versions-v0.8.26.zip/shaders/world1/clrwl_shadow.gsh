#version 430 compatibility


#define DIMENSION_END
#define PROGRAM_GSH
#define PROGRAM_COLORWHEEL


#include "/Lib/PathTracing/Voxelizer/Shadow.glsl"
