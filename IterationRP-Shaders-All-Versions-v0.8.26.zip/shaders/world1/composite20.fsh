#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/Sky_End_FS.glsl"
