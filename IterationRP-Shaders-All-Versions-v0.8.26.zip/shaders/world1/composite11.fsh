#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/DiffuseVariance_FS.glsl"
