#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/DiffuseTracing_FS.glsl"
