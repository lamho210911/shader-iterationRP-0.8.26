#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/SkyImage_CS.glsl"
