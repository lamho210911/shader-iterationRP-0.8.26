#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/VoxelData_Copy_CS.glsl"
