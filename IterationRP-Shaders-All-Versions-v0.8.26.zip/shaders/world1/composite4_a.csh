#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/SH_TRACING_CS.glsl"
