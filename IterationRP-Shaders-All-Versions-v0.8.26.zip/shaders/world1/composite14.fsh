#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/DiffuseSpatial_2_FS.glsl"
