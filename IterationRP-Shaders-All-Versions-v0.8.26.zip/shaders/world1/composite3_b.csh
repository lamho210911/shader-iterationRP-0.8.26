#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/SPD_HandEmission_CS.glsl"
