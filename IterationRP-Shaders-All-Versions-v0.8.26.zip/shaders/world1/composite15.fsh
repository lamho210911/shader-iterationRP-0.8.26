#version 430


#define DIMENSION_END


#include "/Lib/Programs/Composite/DiffuseSpatial_3_FS.glsl"
