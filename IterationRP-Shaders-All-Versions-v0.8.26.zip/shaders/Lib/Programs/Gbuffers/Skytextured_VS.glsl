//Skytextured_VS


#include "/Lib/Settings.glsl"
#include "/Lib/Utilities.glsl"


uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
//uniform int renderStage;
uniform vec2 taaJitter;

out vec3 v_color;
out vec2 v_texCoord;


#if defined SUPER_RESOLUTION || defined CUSTOM_RENDER_RESOLUTION
	#include "/Lib/FidelityFX/FSR2/GbufferScale.glsl"
#endif


void main(){
	//if (renderStage == MC_RENDER_STAGE_MOON){
		gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;
		vec4 worldPos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

		const float rotYAngle = SUNRISE_ROTATION * 0.01745329252;
		const mat3 rotY = mat3(
			cos(rotYAngle), 0.0, -sin(rotYAngle),
			0.0,            1.0,  0.0,
			sin(rotYAngle), 0.0,  cos(rotYAngle)
		);
		worldPos.xyz = worldPos.xyz * rotY;
		gl_Position = gl_ProjectionMatrix * gbufferModelView * worldPos;


	//}else{
	//	gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;
	//}

	#if defined SUPER_RESOLUTION || defined CUSTOM_RENDER_RESOLUTION
		#ifdef CUSTOM_RENDER_RESOLUTION
			RedoProject(gl_Position);
		#endif
		FsrScaleVS(gl_Position, taaJitter);
	#else
		#ifdef TAA
			gl_Position.xy = taaJitter * gl_Position.w + gl_Position.xy;
		#endif
	#endif

	v_color = gl_Color.rgb;
	v_texCoord = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.xy + gl_TextureMatrix[0][3].xy;
}
