

#include "/Lib/Settings.glsl"
#include "/Lib/Utilities.glsl"


#if SR_ENABLE == 1
	const vec2 workGroupsRender = vec2(SR_RENDER_SCALE_FACTOR, SR_RENDER_SCALE_FACTOR);
#elif FSR2_SCALE >= 0
	#if FSR2_SCALE == 0
		const vec2 workGroupsRender = vec2(1.0, 1.0);
	#elif FSR2_SCALE == 1
		const vec2 workGroupsRender = vec2(0.6667, 0.6667);
	#elif FSR2_SCALE == 2
		const vec2 workGroupsRender = vec2(0.5882, 0.5882);
	#elif FSR2_SCALE == 3
		const vec2 workGroupsRender = vec2(0.5, 0.5);
	#elif FSR2_SCALE == 4
		const vec2 workGroupsRender = vec2(0.3333, 0.3333);
	#endif
#else
	const vec2 workGroupsRender = vec2(1.0, 1.0);
#endif

layout (local_size_x = 16, local_size_y = 8) in;


layout (r32f) writeonly uniform image2D img_depthtexS;
#if defined PT_OCCLUDED_WATER_SPECULAR && defined DIMENSION_OVERWORLD
	layout(r32f) writeonly uniform image2D img_waterDepth2D;
#endif


void main(){
	ivec2 drawTexel = ivec2(gl_GlobalInvocationID.xy);

	imageStore(img_depthtexS, drawTexel, vec4(1.0));
	#if defined PT_OCCLUDED_WATER_SPECULAR && defined DIMENSION_OVERWORLD
		imageStore(img_waterDepth2D, drawTexel, vec4(1e20));
	#endif
}