#version 430


#define DIMENSION_OVERWORLD


#include "/Lib/Programs/Composite/DiffuseSpatial_7_FS.glsl"
